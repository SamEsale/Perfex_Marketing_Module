# Release Manifest

## Module Identity

- Module name: `Marketing`
- Module version: `1.1.0`
- Requires at least: `3.2.*`
- Compatible Perfex baseline: `Perfex CRM 3.4.x`

## Active Integrations

- SMTP / Amazon SES campaign delivery
- SES / SNS webhook telemetry
- Inbound email reply webhook
- WhatsApp Business settings, webhook verification, inbound conversations, status reconciliation, manual operator reply workflow, and manual lead conversion workflow

## Deferred Integrations

- Facebook is deferred / inactive in this package
- LinkedIn is deferred / inactive in this package
- YouTube is deferred / inactive as a social integration surface in this package
- Email-builder social icons for Facebook, Instagram, X/Twitter, YouTube, LinkedIn, and Website are content-only presentation elements, not active social inbox integrations
- WhatsApp provider approval, asset access, and token lifecycle remain external Meta prerequisites

## Required Release Docs

- `README.md`
- `INSTALLATION.md`
- `docs/OPERATIONS.md`
- `docs/PRODUCTION_CHECKLIST.md`
- `docs/RELEASE_MANIFEST.md`

## Required Validation Scripts

- `scripts/build_release_package.sh`
- `scripts/verify_release_package.sh`
- `scripts/verify_phase2_regressions.sh`
- `scripts/verify_phase4_integrity_runtime.php`

## Required Public Routes

- `marketing/webhooks/ses_sns`
- `marketing/webhooks/inbound_email`
- `marketing/webhooks/whatsapp`
- `marketing/track/c/{token}`
- `marketing/unsubscribe/{token}`

## Required CSRF Exclusions

- `marketing/webhooks/ses_sns`
- `marketing/webhooks/inbound_email`
- `marketing/webhooks/whatsapp`

## Lifecycle Hooks

- activation hook
- deactivation hook
- uninstall hook
- app init hook for CSRF exclusions
- after-cron hook for queue processing

## Packaging Root Expectations

- ZIP package root must be `marketing/`
- Installed module path must become `modules/marketing/marketing.php`
- Nested `modules/marketing/modules/marketing/marketing.php` is invalid

## Operational Diagnostics

- release build via `bash scripts/build_release_package.sh`
- release package validation via `bash scripts/verify_release_package.sh`
- regression validation via `bash scripts/verify_phase2_regressions.sh`
- runtime integrity diagnostics via `php modules/marketing/scripts/verify_phase4_integrity_runtime.php`

## New Domain / Server Deployment Notes

- Upload the ZIP through `Setup -> Modules`; the package root must remain `marketing/`
- Activation must resolve to `modules/marketing/marketing.php`
- SMTP / SES, inbound reply, WhatsApp, and license values are environment-specific and must be saved after install
- Rendered webhook, click-tracking, unsubscribe, and social asset URLs must come from the current Perfex base URL
- External provider callbacks must be repointed to the new public CRM domain before live traffic is expected

## Full Perfex CRM Migration Notes

- A full CRM migration requires CRM files, a database dump, `application/config/config.php`, `application/config/database.php`, writable-folder permissions, cron, PHP extensions, SSL, and the correct web-server root
- Update the Perfex base URL, SMTP sender domain, provider callback URLs, and any license endpoint/domain binding after restore
- Do not restore production secrets into unintended environments
- Do not use uninstall/reinstall as an upgrade or migration shortcut

## Browser Smoke Expectations

- Company address insert/save/reload/preview remains functional
- Social icons save/reload and render in preview as icon-only links when populated
- Unsubscribe flow remains explicit, tokenized, and suppression-backed
- WhatsApp inbound conversation, status reconciliation, manual reply, and manual lead conversion flows remain operator-visible

## External Dependencies / Approvals

- active Perfex cron
- valid email provider configuration
- SES / SNS provider-side configuration when used
- inbound email webhook delivery when used
- external Meta approval, business asset access, valid token, Phone Number ID, and approved templates for WhatsApp sending

## Release Statements

- No secrets included in distributed release artifacts
- No Perfex core modifications required by this module
- Activation and upgrade use add-only option/schema repair
- Uninstall is distinct from upgrade and clears module-owned options without automatically dropping buyer data or module tables
